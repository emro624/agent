const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());

// Basit health check
app.get('/', (req, res) => {
  res.send('MCP Crypto API is running');
});

// /price?coin=bitcoin
app.get('/price', async (req, res) => {
  const coin = req.query.coin || 'bitcoin';
  try {
    const response = await axios.get(`https://api.coingecko.com/api/v3/simple/price`, {
      params: {
        ids: coin,
        vs_currencies: 'usd',
      },
    });
    res.json({
      coin,
      price: response.data[coin]?.usd || null,
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch price' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
}); 